<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Banking site|Home Page</title>

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        
        <link href="homepgStyle.css" type="text/css" rel="stylesheet">
        
</head>

<body style="margin-top:0px; padding:0px">


 <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">TSF Bank<span class="glyphicon glyphicon-home"></span></a>
                </div>
                <div>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="user.php"><span class="glyphicon glyphicon-user"></span> Our Costumers</a></li>
                        <li><a href="Transaction.php"><span class="glyphicon glyphicon-log-in"></span> Transaction Summary</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <!--banner image part-->
        <div id="banner_image">
        	<div class="container">
            	<div id="banner_content">
                <h4>Welcome to TSF Bank</h4>
                <h1 style="font-size:45px">Banking for all</h1>
                <br />
                	<a href="user.php" class=" btn btn-danger btn-lg active">Transfer Money</a>
                </div>
            </div>
        </div>
        
        <footer>
        	<div class="container">
            	<center><p>Copyright &copy; TSF Bank.All Rights Reserved|Contact Us: +91 90000 00000</p></center>
            </div>
       </footer>

</body>
</html>